"""
Mini-PVM package.
"""

